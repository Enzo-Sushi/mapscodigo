# Google Maps e Geolocation

Exemplo de um projeto Flutter com Geolocalização e Google Maps.

## Configuração

- Renomear o arquivo `.env.example` para `.env`
- Substituir as credenciais no `.env` pelas [chaves de API do Google Maps](https://console.cloud.google.com/google/maps-apis/credentials)
- Executar o projeto no iOS ou Android

