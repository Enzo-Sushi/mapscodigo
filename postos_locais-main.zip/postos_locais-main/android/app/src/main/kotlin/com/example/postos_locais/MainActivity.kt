package com.example.postos_locais

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
